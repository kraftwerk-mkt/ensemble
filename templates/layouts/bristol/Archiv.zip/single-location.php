<?php
/**
 * Single Location Template - Bristol Editorial Style
 * Asymmetric split layout
 * 
 * @package Ensemble
 * @layout Bristol City Festival
 */
if (!defined('ABSPATH')) exit;

get_header();

$location_id = get_the_ID();
$location = es_load_location_data($location_id);

// Image
$has_image = has_post_thumbnail();
$image_url = '';
if (!$has_image && !empty($location['featured_image'])) {
    $image_url = $location['featured_image'];
    $has_image = true;
}

// Category
$location_cats = get_the_terms($location_id, 'location_category');
$category = ($location_cats && !is_wp_error($location_cats)) ? $location_cats[0]->name : '';

// Theme mode
$mode_class = isset($_COOKIE['es_bristol_mode']) && $_COOKIE['es_bristol_mode'] === 'light' ? 'es-mode-light' : '';
?>

<div class="es-bristol <?php echo esc_attr($mode_class); ?>">

    <!-- HERO: Split Layout -->
    <header class="es-bristol-single-hero">
        <!-- Left: Image -->
        <div class="es-bristol-single-hero-media">
            <?php if (has_post_thumbnail()): ?>
                <?php the_post_thumbnail('full'); ?>
            <?php elseif ($image_url): ?>
                <img src="<?php echo esc_url($image_url); ?>" alt="<?php the_title_attribute(); ?>">
            <?php else: ?>
                <div style="width:100%;height:100%;background:linear-gradient(135deg, var(--es-surface) 0%, var(--es-bg-alt) 100%);display:flex;align-items:center;justify-content:center;">
                    <svg width="120" height="120" viewBox="0 0 24 24" fill="none" stroke="var(--es-text-muted)" stroke-width="0.5" opacity="0.3">
                        <path d="M21 10c0 7-9 13-9 13s-9-6-9-13a9 9 0 0 1 18 0z"/>
                        <circle cx="12" cy="10" r="3"/>
                    </svg>
                </div>
            <?php endif; ?>
        </div>
        
        <!-- Right: Content -->
        <div class="es-bristol-single-hero-content">
            <?php if ($category): ?>
            <span class="es-bristol-single-hero-badge"><span><?php echo esc_html($category); ?></span></span>
            <?php endif; ?>
            
            <h1 class="es-bristol-single-hero-title"><?php the_title(); ?></h1>
            
            <?php if (has_excerpt()): ?>
            <p class="es-bristol-single-hero-subtitle"><?php echo get_the_excerpt(); ?></p>
            <?php endif; ?>
            
            <!-- Meta -->
            <div class="es-bristol-single-hero-meta">
                <?php if (!empty($location['address'])): ?>
                <div class="es-bristol-single-hero-meta-item">
                    <div class="es-bristol-single-hero-meta-icon">
                        <svg viewBox="0 0 24 24"><path d="M21 10c0 7-9 13-9 13s-9-6-9-13a9 9 0 0 1 18 0z"/><circle cx="12" cy="10" r="3"/></svg>
                    </div>
                    <div class="es-bristol-single-hero-meta-text">
                        <span class="es-bristol-single-hero-meta-label"><?php _e('Adresse', 'ensemble'); ?></span>
                        <span class="es-bristol-single-hero-meta-value"><?php echo esc_html($location['address']); ?></span>
                    </div>
                </div>
                <?php endif; ?>
                
                <?php if (!empty($location['city'])): ?>
                <div class="es-bristol-single-hero-meta-item">
                    <div class="es-bristol-single-hero-meta-icon">
                        <svg viewBox="0 0 24 24"><path d="M3 9l9-7 9 7v11a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2z"/><polyline points="9 22 9 12 15 12 15 22"/></svg>
                    </div>
                    <div class="es-bristol-single-hero-meta-text">
                        <span class="es-bristol-single-hero-meta-label"><?php _e('Stadt', 'ensemble'); ?></span>
                        <span class="es-bristol-single-hero-meta-value"><?php echo esc_html($location['city']); ?></span>
                    </div>
                </div>
                <?php endif; ?>
                
                <?php if (!empty($location['capacity'])): ?>
                <div class="es-bristol-single-hero-meta-item">
                    <div class="es-bristol-single-hero-meta-icon">
                        <svg viewBox="0 0 24 24"><path d="M17 21v-2a4 4 0 0 0-4-4H5a4 4 0 0 0-4 4v2"/><circle cx="9" cy="7" r="4"/><path d="M23 21v-2a4 4 0 0 0-3-3.87"/><path d="M16 3.13a4 4 0 0 1 0 7.75"/></svg>
                    </div>
                    <div class="es-bristol-single-hero-meta-text">
                        <span class="es-bristol-single-hero-meta-label"><?php _e('Kapazität', 'ensemble'); ?></span>
                        <span class="es-bristol-single-hero-meta-value"><?php echo esc_html(number_format($location['capacity'], 0, ',', '.')); ?> <?php _e('Personen', 'ensemble'); ?></span>
                    </div>
                </div>
                <?php endif; ?>
            </div>
            
            <!-- Social/Website -->
            <?php if (!empty($location['website'])): ?>
            <div class="es-bristol-single-hero-social">
                <a href="<?php echo esc_url($location['website']); ?>" target="_blank" rel="noopener" title="Website">
                    <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><circle cx="12" cy="12" r="10"/><line x1="2" y1="12" x2="22" y2="12"/><path d="M12 2a15.3 15.3 0 0 1 4 10 15.3 15.3 0 0 1-4 10 15.3 15.3 0 0 1-4-10 15.3 15.3 0 0 1 4-10z"/></svg>
                </a>
            </div>
            <?php endif; ?>
        </div>
    </header>

    <!-- BODY -->
    <div class="es-bristol-body">
        <div class="es-bristol-container">
            <div class="es-bristol-layout">
                
                <!-- Main Content -->
                <main class="es-bristol-main">
                    
                    <?php if (!empty($location['content'])): ?>
                    <section class="es-bristol-section">
                        <h2 class="es-bristol-section-title"><?php _e('Über die Location', 'ensemble'); ?></h2>
                        <div class="es-bristol-prose">
                            <?php echo wp_kses_post($location['content']); ?>
                        </div>
                    </section>
                    <?php endif; ?>
                    
                    <!-- Upcoming Events at this location -->
                    <?php 
                    // Query events at this location
                    $events = new WP_Query(array(
                        'post_type' => ensemble_get_post_type('event'),
                        'posts_per_page' => 10,
                        'meta_query' => array(
                            array(
                                'key' => '_event_location',
                                'value' => $location_id,
                                'compare' => '='
                            )
                        ),
                        'meta_key' => '_event_date',
                        'orderby' => 'meta_value',
                        'order' => 'ASC'
                    ));
                    if ($events->have_posts()): 
                    ?>
                    <section class="es-bristol-section">
                        <h2 class="es-bristol-section-title"><?php _e('Kommende Events', 'ensemble'); ?></h2>
                        <div class="es-bristol-events-list">
                            <?php while ($events->have_posts()): $events->the_post(); 
                                $ev = es_load_event_data(get_the_ID());
                                $timestamp = !empty($ev['date']) ? strtotime($ev['date']) : 0;
                            ?>
                            <a href="<?php the_permalink(); ?>" class="es-bristol-event-row">
                                <div class="es-bristol-event-date">
                                    <span class="es-bristol-event-date-day"><?php echo $timestamp ? date_i18n('j', $timestamp) : '—'; ?></span>
                                    <span class="es-bristol-event-date-month"><?php echo $timestamp ? date_i18n('M', $timestamp) : ''; ?></span>
                                </div>
                                <div class="es-bristol-event-info">
                                    <h4><?php the_title(); ?></h4>
                                    <?php if ($timestamp): ?>
                                    <p><?php echo date_i18n('l, H:i', $timestamp); ?> Uhr</p>
                                    <?php endif; ?>
                                </div>
                                <span class="es-bristol-event-arrow">
                                    <svg viewBox="0 0 24 24"><path d="M5 12h14M12 5l7 7-7 7"/></svg>
                                </span>
                            </a>
                            <?php endwhile; wp_reset_postdata(); ?>
                        </div>
                    </section>
                    <?php endif; ?>
                    
                    <!-- Map -->
                    <?php if (!empty($location['lat']) && !empty($location['lng'])): ?>
                    <section class="es-bristol-section">
                        <h2 class="es-bristol-section-title"><?php _e('Anfahrt', 'ensemble'); ?></h2>
                        <div class="es-bristol-map-wrapper">
                            <?php echo do_shortcode('[ensemble_map lat="' . $location['lat'] . '" lng="' . $location['lng'] . '" zoom="15"]'); ?>
                        </div>
                    </section>
                    <?php endif; ?>
                    
                    <!-- Gallery -->
                    <?php if (!empty($location['gallery'])): ?>
                    <section class="es-bristol-section">
                        <h2 class="es-bristol-section-title"><?php _e('Galerie', 'ensemble'); ?></h2>
                        <div class="es-bristol-gallery">
                            <?php foreach ($location['gallery'] as $image): ?>
                            <div class="es-bristol-gallery-item">
                                <img src="<?php echo esc_url($image['url']); ?>" alt="">
                            </div>
                            <?php endforeach; ?>
                        </div>
                    </section>
                    <?php endif; ?>
                    
                </main>
                
                <!-- Sidebar -->
                <aside class="es-bristol-aside">
                    <div class="es-bristol-info-card">
                        <h4 class="es-bristol-info-card-title"><?php _e('Details', 'ensemble'); ?></h4>
                        
                        <?php if (!empty($location['address'])): ?>
                        <div class="es-bristol-info-row">
                            <span class="es-bristol-info-label"><?php _e('Adresse', 'ensemble'); ?></span>
                            <span class="es-bristol-info-value"><?php echo esc_html($location['address']); ?></span>
                        </div>
                        <?php endif; ?>
                        
                        <?php if (!empty($location['postal_code']) || !empty($location['city'])): ?>
                        <div class="es-bristol-info-row">
                            <span class="es-bristol-info-label"><?php _e('Ort', 'ensemble'); ?></span>
                            <span class="es-bristol-info-value"><?php echo esc_html(trim($location['postal_code'] . ' ' . $location['city'])); ?></span>
                        </div>
                        <?php endif; ?>
                        
                        <?php if (!empty($location['country'])): ?>
                        <div class="es-bristol-info-row">
                            <span class="es-bristol-info-label"><?php _e('Land', 'ensemble'); ?></span>
                            <span class="es-bristol-info-value"><?php echo esc_html($location['country']); ?></span>
                        </div>
                        <?php endif; ?>
                        
                        <?php if (!empty($location['capacity'])): ?>
                        <div class="es-bristol-info-row">
                            <span class="es-bristol-info-label"><?php _e('Kapazität', 'ensemble'); ?></span>
                            <span class="es-bristol-info-value"><?php echo esc_html(number_format($location['capacity'], 0, ',', '.')); ?></span>
                        </div>
                        <?php endif; ?>
                        
                        <?php if (!empty($location['phone'])): ?>
                        <div class="es-bristol-info-row">
                            <span class="es-bristol-info-label"><?php _e('Telefon', 'ensemble'); ?></span>
                            <span class="es-bristol-info-value">
                                <a href="tel:<?php echo esc_attr($location['phone']); ?>" class="es-bristol-info-link"><?php echo esc_html($location['phone']); ?></a>
                            </span>
                        </div>
                        <?php endif; ?>
                        
                        <?php if (!empty($location['email'])): ?>
                        <div class="es-bristol-info-row">
                            <span class="es-bristol-info-label"><?php _e('E-Mail', 'ensemble'); ?></span>
                            <span class="es-bristol-info-value">
                                <a href="mailto:<?php echo esc_attr($location['email']); ?>" class="es-bristol-info-link"><?php echo esc_html($location['email']); ?></a>
                            </span>
                        </div>
                        <?php endif; ?>
                        
                        <?php if (!empty($location['website'])): ?>
                        <div class="es-bristol-info-row">
                            <span class="es-bristol-info-label"><?php _e('Website', 'ensemble'); ?></span>
                            <span class="es-bristol-info-value">
                                <a href="<?php echo esc_url($location['website']); ?>" class="es-bristol-info-link" target="_blank" rel="noopener"><?php echo esc_html(str_replace(['https://', 'http://', 'www.'], '', $location['website'])); ?></a>
                            </span>
                        </div>
                        <?php endif; ?>
                    </div>
                    
                    <!-- Directions Button -->
                    <?php if (!empty($location['lat']) && !empty($location['lng'])): ?>
                    <a href="https://www.google.com/maps/dir/?api=1&destination=<?php echo esc_attr($location['lat'] . ',' . $location['lng']); ?>" 
                       class="es-bristol-btn es-bristol-btn-outline" 
                       style="width:100%;margin-top:24px;"
                       target="_blank" rel="noopener">
                        <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
                            <polygon points="3 11 22 2 13 21 11 13 3 11"/>
                        </svg>
                        <?php _e('Route planen', 'ensemble'); ?>
                    </a>
                    <?php endif; ?>
                </aside>
                
            </div>
        </div>
    </div>

    <!-- Theme Toggle -->
    <button class="es-bristol-theme-toggle" aria-label="<?php esc_attr_e('Theme wechseln', 'ensemble'); ?>">
        <svg class="icon-sun" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
            <circle cx="12" cy="12" r="5"/><line x1="12" y1="1" x2="12" y2="3"/><line x1="12" y1="21" x2="12" y2="23"/><line x1="4.22" y1="4.22" x2="5.64" y2="5.64"/><line x1="18.36" y1="18.36" x2="19.78" y2="19.78"/><line x1="1" y1="12" x2="3" y2="12"/><line x1="21" y1="12" x2="23" y2="12"/><line x1="4.22" y1="19.78" x2="5.64" y2="18.36"/><line x1="18.36" y1="5.64" x2="19.78" y2="4.22"/>
        </svg>
        <svg class="icon-moon" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
            <path d="M21 12.79A9 9 0 1 1 11.21 3 7 7 0 0 0 21 12.79z"/>
        </svg>
    </button>

</div>

<script>
(function() {
    const toggle = document.querySelector('.es-bristol-theme-toggle');
    const root = document.querySelector('.es-bristol');
    toggle?.addEventListener('click', function() {
        root.classList.toggle('es-mode-light');
        document.cookie = 'es_bristol_mode=' + (root.classList.contains('es-mode-light') ? 'light' : 'dark') + ';path=/;max-age=31536000';
    });
})();
</script>

<?php get_footer(); ?>
