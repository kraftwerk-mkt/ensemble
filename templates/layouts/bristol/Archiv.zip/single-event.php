<?php
/**
 * Single Event Template - Bristol Editorial Style
 * Asymmetric split layout, bold typography
 * 
 * @package Ensemble
 * @layout Bristol City Festival
 */
if (!defined('ABSPATH')) exit;

get_header();

$event_id = get_the_ID();
$event = es_load_event_data($event_id);

// Date formatting
$date_day = '';
$date_month = '';
$date_full = '';
$time_display = '';
$date_weekday = '';

if (!empty($event['date'])) {
    $timestamp = strtotime($event['date']);
    $date_day = date_i18n('j', $timestamp);
    $date_month = date_i18n('F', $timestamp);
    $date_full = date_i18n('j. F Y', $timestamp);
    $date_weekday = date_i18n('l', $timestamp);
    $time_display = date_i18n('H:i', $timestamp);
}

// Location
$location_name = !empty($event['location']['name']) ? $event['location']['name'] : '';
$location_address = !empty($event['location']['address']) ? $event['location']['address'] : '';
$location_id = !empty($event['location']['id']) ? $event['location']['id'] : 0;

// Category
$category = !empty($event['categories']) ? $event['categories'][0]->name : '';

// Theme mode
$mode_class = isset($_COOKIE['es_bristol_mode']) && $_COOKIE['es_bristol_mode'] === 'light' ? 'es-mode-light' : '';
?>

<div class="es-bristol <?php echo esc_attr($mode_class); ?>">

    <!-- HERO: Split Layout -->
    <header class="es-bristol-single-hero">
        <!-- Left: Image -->
        <div class="es-bristol-single-hero-media">
            <?php if (has_post_thumbnail()): ?>
                <?php the_post_thumbnail('full'); ?>
            <?php else: ?>
                <div style="width:100%;height:100%;background:linear-gradient(135deg, var(--es-surface) 0%, var(--es-bg-alt) 100%);"></div>
            <?php endif; ?>
        </div>
        
        <!-- Right: Content -->
        <div class="es-bristol-single-hero-content">
            <?php if ($category): ?>
            <span class="es-bristol-single-hero-badge"><span><?php echo esc_html($category); ?></span></span>
            <?php endif; ?>
            
            <h1 class="es-bristol-single-hero-title"><?php the_title(); ?></h1>
            
            <?php if (has_excerpt()): ?>
            <p class="es-bristol-single-hero-subtitle"><?php echo get_the_excerpt(); ?></p>
            <?php endif; ?>
            
            <!-- Meta with icons -->
            <div class="es-bristol-single-hero-meta">
                <?php if ($date_full): ?>
                <div class="es-bristol-single-hero-meta-item">
                    <div class="es-bristol-single-hero-meta-icon">
                        <svg viewBox="0 0 24 24"><rect x="3" y="4" width="18" height="18" rx="2"/><line x1="16" y1="2" x2="16" y2="6"/><line x1="8" y1="2" x2="8" y2="6"/><line x1="3" y1="10" x2="21" y2="10"/></svg>
                    </div>
                    <div class="es-bristol-single-hero-meta-text">
                        <span class="es-bristol-single-hero-meta-label"><?php _e('Datum', 'ensemble'); ?></span>
                        <span class="es-bristol-single-hero-meta-value"><?php echo esc_html($date_weekday . ', ' . $date_full); ?></span>
                    </div>
                </div>
                <?php endif; ?>
                
                <?php if ($time_display && $time_display !== '00:00'): ?>
                <div class="es-bristol-single-hero-meta-item">
                    <div class="es-bristol-single-hero-meta-icon">
                        <svg viewBox="0 0 24 24"><circle cx="12" cy="12" r="10"/><polyline points="12 6 12 12 16 14"/></svg>
                    </div>
                    <div class="es-bristol-single-hero-meta-text">
                        <span class="es-bristol-single-hero-meta-label"><?php _e('Einlass', 'ensemble'); ?></span>
                        <span class="es-bristol-single-hero-meta-value"><?php echo esc_html($time_display); ?> Uhr</span>
                    </div>
                </div>
                <?php endif; ?>
                
                <?php if ($location_name): ?>
                <div class="es-bristol-single-hero-meta-item">
                    <div class="es-bristol-single-hero-meta-icon">
                        <svg viewBox="0 0 24 24"><path d="M21 10c0 7-9 13-9 13s-9-6-9-13a9 9 0 0 1 18 0z"/><circle cx="12" cy="10" r="3"/></svg>
                    </div>
                    <div class="es-bristol-single-hero-meta-text">
                        <span class="es-bristol-single-hero-meta-label"><?php _e('Location', 'ensemble'); ?></span>
                        <span class="es-bristol-single-hero-meta-value">
                            <?php if ($location_id): ?>
                            <a href="<?php echo get_permalink($location_id); ?>" class="es-bristol-info-link"><?php echo esc_html($location_name); ?></a>
                            <?php else: ?>
                            <?php echo esc_html($location_name); ?>
                            <?php endif; ?>
                        </span>
                    </div>
                </div>
                <?php endif; ?>
            </div>
        </div>
    </header>

    <!-- BODY: Asymmetric Grid -->
    <div class="es-bristol-body">
        <div class="es-bristol-container">
            <div class="es-bristol-layout">
                
                <!-- Main Content -->
                <main class="es-bristol-main">
                    
                    <?php 
                    // Hook: Before main content
                    do_action('ensemble_single_event_before_content', $event_id, $event); 
                    ?>
                    
                    <?php if (!empty($event['content'])): ?>
                    <section class="es-bristol-section">
                        <h2 class="es-bristol-section-title"><?php _e('Über das Event', 'ensemble'); ?></h2>
                        <div class="es-bristol-prose">
                            <?php echo wp_kses_post($event['content']); ?>
                        </div>
                    </section>
                    <?php endif; ?>
                    
                    <?php 
                    // Hook: After description (Agenda, Timetable, etc.)
                    do_action('ensemble_single_event_after_description', $event_id, $event); 
                    ?>
                    
                    <!-- Artists -->
                    <?php if (!empty($event['artists'])): ?>
                    <section class="es-bristol-section">
                        <h2 class="es-bristol-section-title"><?php _e('Line-Up', 'ensemble'); ?></h2>
                        <div class="es-bristol-artist-grid">
                            <?php foreach ($event['artists'] as $artist): ?>
                            <a href="<?php echo get_permalink($artist->ID); ?>" class="es-bristol-artist-item">
                                <?php if (has_post_thumbnail($artist->ID)): ?>
                                    <?php echo get_the_post_thumbnail($artist->ID, 'medium'); ?>
                                <?php else: ?>
                                    <div style="width:100%;height:100%;background:linear-gradient(135deg, var(--es-surface), var(--es-bg-alt));display:flex;align-items:center;justify-content:center;">
                                        <svg width="32" height="32" viewBox="0 0 24 24" fill="none" stroke="var(--es-text-muted)" stroke-width="1.5">
                                            <path d="M20 21v-2a4 4 0 0 0-4-4H8a4 4 0 0 0-4 4v2"/>
                                            <circle cx="12" cy="7" r="4"/>
                                        </svg>
                                    </div>
                                <?php endif; ?>
                                <span class="es-bristol-artist-item-name"><?php echo esc_html($artist->post_title); ?></span>
                            </a>
                            <?php endforeach; ?>
                        </div>
                    </section>
                    <?php endif; ?>
                    
                    <?php 
                    // Hook: After artists (Sponsors, Downloads, etc.)
                    do_action('ensemble_single_event_after_artists', $event_id, $event); 
                    ?>
                    
                    <!-- Gallery -->
                    <?php if (!empty($event['gallery'])): ?>
                    <section class="es-bristol-section">
                        <h2 class="es-bristol-section-title"><?php _e('Galerie', 'ensemble'); ?></h2>
                        <div class="es-bristol-gallery">
                            <?php foreach ($event['gallery'] as $image): ?>
                            <div class="es-bristol-gallery-item">
                                <img src="<?php echo esc_url($image['url']); ?>" alt="<?php echo esc_attr($image['alt'] ?? ''); ?>">
                            </div>
                            <?php endforeach; ?>
                        </div>
                    </section>
                    <?php endif; ?>
                    
                    <?php 
                    // Hook: After gallery (FAQ, etc.)
                    do_action('ensemble_single_event_after_gallery', $event_id, $event); 
                    ?>
                    
                    <!-- Map -->
                    <?php if (!empty($event['location']['lat']) && !empty($event['location']['lng'])): ?>
                    <section class="es-bristol-section">
                        <h2 class="es-bristol-section-title"><?php _e('Anfahrt', 'ensemble'); ?></h2>
                        <div class="es-bristol-map-wrapper">
                            <?php echo do_shortcode('[ensemble_map lat="' . $event['location']['lat'] . '" lng="' . $event['location']['lng'] . '" zoom="15"]'); ?>
                        </div>
                    </section>
                    <?php endif; ?>
                    
                    <?php 
                    // Hook: After main content
                    do_action('ensemble_single_event_after_content', $event_id, $event); 
                    ?>
                    
                </main>
                
                <!-- Sidebar -->
                <aside class="es-bristol-aside">
                    
                    <?php 
                    // Hook: Before sidebar content
                    do_action('ensemble_single_event_sidebar_before', $event_id, $event); 
                    ?>
                    
                    <!-- Tickets -->
                    <?php if (!empty($event['ticket_categories']) || !empty($event['ticket_link'])): ?>
                    <div class="es-bristol-tickets-card">
                        <h3 class="es-bristol-tickets-card-title"><?php _e('Tickets', 'ensemble'); ?></h3>
                        
                        <?php if (!empty($event['ticket_categories'])): ?>
                        <div class="es-bristol-ticket-list">
                            <?php foreach ($event['ticket_categories'] as $cat): ?>
                            <div class="es-bristol-ticket-cat <?php echo !empty($cat['sold_out']) ? 'es-sold-out' : ''; ?>">
                                <span class="es-bristol-cat-name"><?php echo esc_html($cat['name']); ?></span>
                                <span class="es-bristol-cat-price">
                                    <?php if (!empty($cat['sold_out'])): ?>
                                        <?php _e('Ausverkauft', 'ensemble'); ?>
                                    <?php else: ?>
                                        <?php echo esc_html(number_format($cat['price'], 2, ',', '.') . ' €'); ?>
                                    <?php endif; ?>
                                </span>
                            </div>
                            <?php endforeach; ?>
                        </div>
                        <?php endif; ?>
                        
                        <?php if (!empty($event['ticket_link'])): ?>
                        <a href="<?php echo esc_url($event['ticket_link']); ?>" class="es-bristol-btn es-bristol-btn-primary" style="width:100%;margin-top:24px;" target="_blank">
                            <?php _e('Tickets kaufen', 'ensemble'); ?>
                            <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M5 12h14M12 5l7 7-7 7"/></svg>
                        </a>
                        <?php endif; ?>
                    </div>
                    <?php endif; ?>
                    
                    <?php 
                    // Hook: After tickets (Booking Widget, etc.)
                    do_action('ensemble_single_event_after_tickets', $event_id, $event); 
                    ?>
                    
                    <!-- Event Info -->
                    <div class="es-bristol-info-card">
                        <h4 class="es-bristol-info-card-title"><?php _e('Details', 'ensemble'); ?></h4>
                        
                        <?php if (!empty($event['organizer'])): ?>
                        <div class="es-bristol-info-row">
                            <span class="es-bristol-info-label"><?php _e('Veranstalter', 'ensemble'); ?></span>
                            <span class="es-bristol-info-value"><?php echo esc_html($event['organizer']); ?></span>
                        </div>
                        <?php endif; ?>
                        
                        <?php if ($location_address): ?>
                        <div class="es-bristol-info-row">
                            <span class="es-bristol-info-label"><?php _e('Adresse', 'ensemble'); ?></span>
                            <span class="es-bristol-info-value"><?php echo esc_html($location_address); ?></span>
                        </div>
                        <?php endif; ?>
                        
                        <?php if (!empty($event['age_restriction'])): ?>
                        <div class="es-bristol-info-row">
                            <span class="es-bristol-info-label"><?php _e('Alter', 'ensemble'); ?></span>
                            <span class="es-bristol-info-value"><?php echo esc_html($event['age_restriction']); ?></span>
                        </div>
                        <?php endif; ?>
                        
                        <?php if (!empty($event['status']) && $event['status'] !== 'scheduled'): ?>
                        <div class="es-bristol-info-row">
                            <span class="es-bristol-info-label"><?php _e('Status', 'ensemble'); ?></span>
                            <span class="es-bristol-info-value">
                                <?php 
                                $statuses = array(
                                    'cancelled' => __('Abgesagt', 'ensemble'),
                                    'postponed' => __('Verschoben', 'ensemble'),
                                    'soldout' => __('Ausverkauft', 'ensemble')
                                );
                                echo esc_html($statuses[$event['status']] ?? $event['status']);
                                ?>
                            </span>
                        </div>
                        <?php endif; ?>
                    </div>
                    
                    <?php 
                    // Hook: After sidebar content
                    do_action('ensemble_single_event_sidebar_after', $event_id, $event); 
                    ?>
                    
                </aside>
                
            </div>
        </div>
    </div>
    
    <?php 
    // Hook: Before related events (for Related Events addon override)
    do_action('ensemble_single_event_before_related', $event_id, $event); 
    ?>
    
    <!-- Related Events -->
    <?php
    // Get category for related events
    $event_cats = !empty($event['categories']) ? wp_list_pluck($event['categories'], 'term_id') : array();
    
    $related_args = array(
        'post_type' => ensemble_get_post_type('event'),
        'posts_per_page' => 6,
        'post__not_in' => array($event_id),
        'meta_key' => '_event_date',
        'orderby' => 'meta_value',
        'order' => 'ASC'
    );
    
    // If we have categories, prefer same category
    if (!empty($event_cats)) {
        $related_args['tax_query'] = array(
            array(
                'taxonomy' => 'event_category',
                'field' => 'term_id',
                'terms' => $event_cats
            )
        );
    }
    
    $related = new WP_Query($related_args);
    if ($related->have_posts()):
    ?>
    <section class="es-bristol-related">
        <div class="es-bristol-related-header">
            <h2 class="es-bristol-related-title"><?php _e('Weitere Events', 'ensemble'); ?></h2>
            <div class="es-bristol-related-nav">
                <button class="es-related-prev"><svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M19 12H5M12 19l-7-7 7-7"/></svg></button>
                <button class="es-related-next"><svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M5 12h14M12 5l7 7-7 7"/></svg></button>
            </div>
        </div>
        <div class="es-bristol-related-scroll">
            <?php while ($related->have_posts()): $related->the_post(); 
                // Try to load the event-card template
                $template_path = ES_PLUGIN_DIR . 'templates/layouts/bristol/event-card.php';
                if (file_exists($template_path)) {
                    include($template_path);
                } else {
                    // Fallback: Simple card
                    $ev = es_load_event_data(get_the_ID());
                    ?>
                    <article class="es-bristol-card">
                        <a href="<?php the_permalink(); ?>" class="es-bristol-card-link">
                            <div class="es-bristol-card-media">
                                <?php if (has_post_thumbnail()): ?>
                                    <?php the_post_thumbnail('medium_large'); ?>
                                <?php endif; ?>
                            </div>
                            <div class="es-bristol-card-title-bar">
                                <h3 class="es-bristol-card-title"><?php the_title(); ?></h3>
                            </div>
                        </a>
                    </article>
                    <?php
                }
            endwhile; wp_reset_postdata(); ?>
        </div>
    </section>
    <?php endif; ?>

    <!-- Theme Toggle -->
    <button class="es-bristol-theme-toggle" aria-label="<?php esc_attr_e('Theme wechseln', 'ensemble'); ?>">
        <svg class="icon-sun" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
            <circle cx="12" cy="12" r="5"/><line x1="12" y1="1" x2="12" y2="3"/><line x1="12" y1="21" x2="12" y2="23"/><line x1="4.22" y1="4.22" x2="5.64" y2="5.64"/><line x1="18.36" y1="18.36" x2="19.78" y2="19.78"/><line x1="1" y1="12" x2="3" y2="12"/><line x1="21" y1="12" x2="23" y2="12"/><line x1="4.22" y1="19.78" x2="5.64" y2="18.36"/><line x1="18.36" y1="5.64" x2="19.78" y2="4.22"/>
        </svg>
        <svg class="icon-moon" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
            <path d="M21 12.79A9 9 0 1 1 11.21 3 7 7 0 0 0 21 12.79z"/>
        </svg>
    </button>

</div>

<script>
(function() {
    const toggle = document.querySelector('.es-bristol-theme-toggle');
    const root = document.querySelector('.es-bristol');
    
    toggle?.addEventListener('click', function() {
        root.classList.toggle('es-mode-light');
        const isLight = root.classList.contains('es-mode-light');
        document.cookie = 'es_bristol_mode=' + (isLight ? 'light' : 'dark') + ';path=/;max-age=31536000';
    });
    
    // Related scroll
    const scroll = document.querySelector('.es-bristol-related-scroll');
    const prev = document.querySelector('.es-related-prev');
    const next = document.querySelector('.es-related-next');
    
    prev?.addEventListener('click', () => scroll.scrollBy({ left: -350, behavior: 'smooth' }));
    next?.addEventListener('click', () => scroll.scrollBy({ left: 350, behavior: 'smooth' }));
})();
</script>

<?php get_footer(); ?>
